import connexion
from connexion import NoContent
import json
from datetime import datetime
import os
import requests

# maxEvents = 10
# eventFile = "events.json"

# def writeJson(body):
#     timestamp = datetime.now()
#     if os.path.isfile(eventFile):
#         with open(eventFile,"r+") as file:
#             info = json.load(file)
#     else:
#         info = []
#     info.append(
#     {
#     "received_timestamp":str(timestamp), 
#     "request_data":body
#     })
#     if len(info) > maxEvents:
#         info = info[1:]
#     with open(eventFile, "w+") as writeFile:
#         writeFile.write(json.dumps(info, indent=2))


def ticket_info(body):
    """ Adds a new ticket information to the system """
    # body_ticket = f"ticket_num is {body['ticket_num']}, movie_title is {body['movie_title']}, runtime is {body['runtime']}, price is {body['price']}"
    requests.post("http://localhost:8090/movie/ticket", json=body, headers={"Content-Type": "application/json"})
    return NoContent, 201

def review_info(body):
    """ Adds a new review to the system """
    # body_review = f"review_id is {body['review_id']}, movie_title is {body['movie_title']}, gender is {body['gender']}, age is {body['age']}, rating is {body['rating']}"
    # writeJson(body_review)
    requests.post("http://localhost:8090/movie/review", json=body, headers={"Content-Type": "application/json"})
    return NoContent, 201

app = connexion.FlaskApp(__name__, specification_dir='')
app.add_api("openapi.yml", strict_validation=True, validate_responses=True)


if __name__ == "__main__":
    app.run(port=8080, debug=True)
